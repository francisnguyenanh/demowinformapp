﻿-- UPDATE script for table M_TORIHIKISAKI_KAKEKIN_ZANDAKA (columns containing NAME, TEL, FAX, POST, ADDRESS, TANTOU, CREATE_USER, UPDATE_USER, FURIGANA)
-- Số dòng dữ liệu: 0

