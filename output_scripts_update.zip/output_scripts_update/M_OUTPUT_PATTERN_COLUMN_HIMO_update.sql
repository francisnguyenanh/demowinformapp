﻿-- UPDATE script for table M_OUTPUT_PATTERN_COLUMN_HIMO (columns containing NAME, TEL, FAX, POST, ADDRESS, TANTOU, CREATE_USER, UPDATE_USER, FURIGANA)
-- Số dòng dữ liệu: 0

